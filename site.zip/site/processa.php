<?php

session_start();

include_once('conexao.php');
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL, FILTER_VALIDATE_EMAIL);
$telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);

$resul= "INSERT INTO usuarios(nome,email,telefone) VALUES('$nome', '$email', '$telefone')";
$resultado = mysqli_query($conn, $resul);
if(mysqli_insert_id($conn)){
    $_SESSION['msg'] = "usuario cadastrado com sucesso";
    header('location: contacts.php');
}else{
    $_SESSION['msg'] = "usuario não cadastrado";
    header('location: contacts.php');
}
?>