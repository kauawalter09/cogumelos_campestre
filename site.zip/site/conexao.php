<?php
 $servidor= "localhost";
 $user="root";
 $senha="";
 $dbname="cadastro";
 
 $conn= mysqli_connect($servidor,$user,$senha,$dbname);